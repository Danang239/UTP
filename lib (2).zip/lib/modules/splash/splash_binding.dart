// lib/modules/splash/splash_binding.dart
import 'package:get/get.dart';

class SplashBinding extends Bindings {
  @override
  void dependencies() {}
}
