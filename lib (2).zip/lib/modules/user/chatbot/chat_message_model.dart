// lib/modules/chatbot/chat_message_model.dart
class ChatMessage {
  final bool fromBot;
  final String text;

  const ChatMessage({required this.fromBot, required this.text});
}
